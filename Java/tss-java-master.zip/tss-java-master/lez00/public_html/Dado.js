export default class Dado{
      constructor(){
          
      }
      
      lancio(){
          return Math.floor(Math.random() * 6) +1;
      }
}


