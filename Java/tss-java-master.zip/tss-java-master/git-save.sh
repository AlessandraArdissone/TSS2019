#!/bin/bash
git add -A && git commit -m "modifiche"
git push origin master
