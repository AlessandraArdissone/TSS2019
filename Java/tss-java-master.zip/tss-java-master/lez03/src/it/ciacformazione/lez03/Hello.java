/*
 */
package it.ciacformazione.lez03;


public class Hello {
    
    //partenza del programma
    public static void main(String[] args) {
        
        int x = 10;
        
        System.out.println("la variabile X contiene: " + x);
        
        char carattereSpeciale = 'c';
        
        String msg = "ciao";
    }
}
