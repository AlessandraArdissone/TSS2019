export default class AbstractService{
        constructor(){
            this.baseUrl="http://localhost:8080/nostalciac/resources";
        }
}


